#! /usr/bin/env python3
import json
from services.warehouse_service import warehouse_service

data = json.dumps(
    dict(warehouse_service.warehouse),
    indent=4,
    ensure_ascii=False
)
print(data)
