from core.Cell import Cell
from core.Place import Place
from providers.hardware_provider import hardware_provider, HardwareProvider


class HardwareService:

    def __init__(self, hardware_provider: HardwareProvider):
        self.hardware_provider = hardware_provider
        self.schema = self.hardware_provider.load_schema()

    def create_places(self):
        cells = {}
        places = {}
        size_x = self.schema["size"]["size_x"]
        size_y = self.schema["size"]["size_y"]
        for x in range(1, size_x + 1):
            for y in range(1, size_y + 1):
                cell = Cell(x=x, y=y)
                cells[cell.name] = cell
        for merged_cell in self.schema["merged"]:
            place = Place()
            for cell_name in merged_cell:
                place.add_cells(cells.pop(cell_name))
            places.update({place.uuid: place})
        for cell in cells.values():
            place = Place(cells=[cell])
            places.update({place.uuid: place})
        return places


hardware_service = HardwareService(hardware_provider)

__all__ = ["HardwareService", "hardware_service"]
