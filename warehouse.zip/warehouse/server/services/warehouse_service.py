import json
from core.Warehouse import Warehouse
from services.hardware_service import hardware_service
from providers.database_provider import database_provider
from core.Invoice import Invoice


class WarehouseService:
    def __init__(self, hardware_service, database_provider):
        self.hardware_service = hardware_service
        self.database_provider = database_provider
        self.places = self.hardware_service.create_places()
        schema = json.dumps(self.hardware_service.schema)
        self.warehouse = Warehouse()
        if schema != self.database_provider.load_schema():
            print("Creating tables...")
            self.database_provider.create_places(self.places)
            self.database_provider.save_schema(schema)
            places = self.places
        else:
            places = self.\
                database_provider.get_all_places_from_warehouse()
        for place in places.values():
            self.warehouse.add_place(place)

    @property
    def remote(self):
        data = self.database_provider.get_all_things_from_remote_warehouse()
        return data

    def get_places(self):
        return []

    def pull_thing(self, *, place_uuid="", thing_uuid=""):
        place = self.warehouse.find(place_uuid)
        if place is not None:
            if place.find(thing_uuid) is not None:
                self.warehouse.pull_thing(place)
                self.database_provider.pull_thing(place)
            else:
                raise Exception(f"thing with {thing_uuid} not found")
        else:
            raise Exception(f"place with {place_uuid} not found")

    def load_data(self, data):
        invoice = Invoice(data=data)
        for thing in invoice:
            try:
                place = self.warehouse.add_thing(thing)
                self.database_provider.push_thing(thing=thing, place=place)
            except Exception:
                print(f"send thing {dict(thing)} INTO REMOTE")
                try:
                    self.database_provider.push_thing_into_remote_warehouse(thing)
                except Exception as error:
                    print(error)


warehouse_service = WarehouseService(hardware_service, database_provider)

__all__ = ["WarehouseService", "warehouse_service"]
