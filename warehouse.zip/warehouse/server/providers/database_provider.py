import sys
import os
import sqlite3
from config import CONFIG
from collections import namedtuple
from pathlib import Path
from core.Cell import Cell
from core.Place import Place
from core.Thing import Thing


class DBProvider:

    @staticmethod
    def make_attributes(names):
        return namedtuple(
            "Attributes", names, defaults=list(range(len(names)))
        )()

    def __init__(self, config):
        self._conn = None
        self._config = namedtuple(
            "SQLite",
            ["database_name", "dir_name"],
            defaults=[
                config.get("database_name", "warehouse.db"),
                config.get("dir_name", "./database")
            ]
        )()
        self._path = Path(self._config.dir_name) / self._config.database_name
        if not os.path.isdir(self._config.dir_name):
            os.makedirs(self._config.dir_name)
        if not os.path.isfile(self._path):
            conn = self.open()
            conn.executescript(SQLScript.CREATE_TABLES)
            conn.commit()
            conn.close()

    def open(self):
        return sqlite3.connect(self._path)

    def load_schema(self):
        conn = self.open()
        schema = conn.execute("SELECT * FROM `schema`;").fetchall()
        conn.close()
        return schema[0][0] if schema else ""

    def save_schema(self, data):
        conn = self.open()
        conn.executescript(
            f"INSERT INTO `schema` VALUES('{data}')"
        )
        conn.close()

    def create_cells(self, cells, conn=None):
        conn = conn if conn else self.open()
        _data = []
        if not isinstance(cells, list):
            cells = [cells]
        for cell in cells:
            if isinstance(cell, Cell):
                _data.append((
                    cell.uuid,
                    cell.x_coordinate,
                    cell.y_coordinate,
                    cell.name,
                    int(cell.is_empty)
                ))
        conn = self.open()
        conn.executemany(
            "INSERT INTO cell VALUES(?, ?, ?, ?, ?)",
            _data
        )
        conn.commit()
        conn.close()

    def create_places(self, places, conn=None):
        conn = conn if conn else self.open()
        conn.executescript(SQLScript.DROP_TABLES)
        conn.executescript(SQLScript.CREATE_TABLES)
        for place in places.values():
            try:
                conn.executemany(
                    "INSERT INTO `place` VALUES(?, ?, ?, ?, ?)",
                    [(
                        place.uuid,
                        place.volume,
                        place.free_volume,
                        int(place.is_empty),
                        place.weight
                    )]
                )
                conn.commit()
            except Exception as error:
                raise error
                sys.stderr.write(f"{error}\n")
            for cell in place.cells.values():
                self.create_cells(cell, conn)
                try:
                    print(f"place: {place.uuid}  cell: {cell.uuid}")
                    conn.executescript(
                        "".join([
                            "INSERT INTO `place_has_cells` VALUES",
                            f"('{place.uuid}', '{cell.uuid}')"
                        ])
                    )
                    conn.commit()
                except Exception as error:
                    raise error
                    sys.stderr.write(f"{error}\n")
        conn.close()

    def push_thing(self, *, place, thing):
        conn = self.open()
        cursor = conn.execute(
            f"SELECT * FROM place_has_thing WHERE place_uuid = '{place.uuid}';"
        )
        if len(cursor.fetchall()):
            raise Exception(f"place {place.uuid} is not empty")
        conn.executescript(
            f"UPDATE place SET is_empty = 0 WHERE place.uuid = '{place.uuid}';"
        )
        conn.commit()
        conn.executemany(
            """\
INSERT INTO thing(uuid, name, mass, width, height, depth)
    VALUES(?, ?, ?, ?, ?, ?)""",
            [(
                thing.uuid,
                thing.name,
                thing.mass,
                thing.width,
                thing.height,
                thing.depth
            )]
        )
        conn.executemany(
            "INSERT INTO place_has_thing(place_uuid, thing_uuid) VALUES(?, ?)",
            [(place.uuid, thing.uuid)]
        )
        conn.commit()
        conn.close()

    def pull_thing(self, place):
        conn = self.open()
        data = conn.execute(
            f"SELECT * FROM place_has_thing WHERE place_uuid = '{place.uuid}';"
        ).fetchall()
        if not len(data):
            raise Exception(f"place {place.uuid} is empty")
        for place_has_thing in data:
            place_uuid, thing_uuid = place_has_thing
            conn.executescript(
                f"DELETE FROM place_has_thing WHERE place_uuid = '{place_uuid}';"
            )
            data = conn.execute(
                f"SELECT * FROM thing WHERE uuid = '{thing_uuid}';"
            )

            conn.commit()
            conn.executescript(
                f"DELETE FROM thing WHERE uuid = '{thing_uuid}';"
            )
            conn.executescript(
                f"UPDATE place SET is_empty = 1 WHERE place.uuid = '{place.uuid}';"
            )
            conn.commit()
        conn.close()
        return data

    def get_all_places_from_warehouse(self):
        conn = self.open()
        places_data = conn.execute(SQLScript.GET_PLACES_AND_CELLS).fetchall()
        places = {}
        keys = DBProvider.make_attributes([
            "place_uuid",
            "volume",
            "free_volume",
            "weight",
            "is_empty",
            "cell_uuid",
            "name",
            "x",
            "y"
        ])
        for place_data in places_data:
            place = places.get(place_data[keys.place_uuid])
            if place is None:
                place = Place(
                    uuid=place_data[keys.place_uuid],
                    weight=place_data[keys.weight],
                    volume=place_data[keys.volume]
                )
                places[place.uuid] = place
            cell = Cell(
                uuid=place_data[keys.cell_uuid],
                x=place_data[keys.x],
                y=place_data[keys.y]
            )
            place.add_cells(cell, False)
        for place_uuid in places.keys():
            data = conn.execute(f"""\
SELECT
    thing.uuid,
    thing.name,
    thing.mass,
    thing.width,
    thing.height,
    thing.depth
FROM place_has_thing JOIN thing
    ON thing.uuid = place_has_thing.thing_uuid
        AND place_has_thing.place_uuid = '{place_uuid}';""").fetchall()
            attrs = DBProvider.make_attributes([
                "uuid",
                "name",
                "mass",
                "width",
                "height",
                "depth"
            ])
            for thing_data in data:
                thing = Thing(
                    uuid=thing_data[attrs.uuid],
                    name=thing_data[attrs.name],
                    mass=thing_data[attrs.mass],
                    width=thing_data[attrs.width],
                    height=thing_data[attrs.height],
                    depth=thing_data[attrs.depth]
                )
                place = places.get(place_uuid)
                place.push(thing)
        conn.close()
        return places

    def get_free_places_from_warehouse(self):
        conn = self.open()
        data = conn.execute(SQLScript.GET_ALL_FREE_PLACES).fetchall()
        conn.close()
        return data

    def get_all_things_from_remote_warehouse(self):
        conn = self.open()
        data = conn.execute(
            SQLScript.GET_THINGS_FROM_REMOTE_WAREHOUSE
        ).fetchall()
        conn.close()
        things = {}
        attrs = DBProvider.make_attributes([
            "uuid", "name", "mass", "width", "height", "depth"
        ])
        for thing_data in data:
            thing = Thing(
                uuid=thing_data[attrs.uuid],
                name=thing_data[attrs.name],
                mass=thing_data[attrs.mass],
                width=thing_data[attrs.width],
                height=thing_data[attrs.height],
                depth=thing_data[attrs.depth]
            )
            things[thing.uuid] = thing
        return things

    def push_thing_into_remote_warehouse(self, thing):
        conn = self.open()
        conn.executemany(
            """\
INSERT INTO thing(uuid, name, mass, width, height, depth)
    VALUES(?, ?, ?, ?, ?, ?)""",
            [(
                thing.uuid,
                thing.name,
                thing.mass,
                thing.width,
                thing.height,
                thing.depth
            )]
        )
        conn.executescript(
            f"INSERT INTO remote_warehouse(thing_uuid) VALUES('{thing.uuid}');"
        )
        conn.close()


class SQLScript:
    GET_THINGS_FROM_REMOTE_WAREHOUSE = """\
SELECT
  thing.uuid,
  thing.name,
  thing.mass,
  thing.width,
  thing.height,
  thing.depth
FROM remote_warehouse JOIN thing ON remote_warehouse.thing_uuid = thing.uuid;
"""

    GET_ALL_DATA = """\
---
--- GET_ALL_DATA
---
SELECT
    PLACE_AND_CELLS_AND_THINGS.place_uuid,
    PLACE_AND_CELLS_AND_THINGS.volume,
    PLACE_AND_CELLS_AND_THINGS.free_volume,
    PLACE_AND_CELLS_AND_THINGS.weight,
    PLACE_AND_CELLS_AND_THINGS.is_empty,
    PLACE_AND_CELLS_AND_THINGS.cell_uuid,
    PLACE_AND_CELLS_AND_THINGS.name,
    PLACE_AND_CELLS_AND_THINGS.x_coordinate,
    PLACE_AND_CELLS_AND_THINGS.y_coordinate,
    PLACE_AND_CELLS_AND_THINGS.thing_uuid,
    thing.name,
    thing.mass,
    thing.width,
    thing.height,
    thing.depth
FROM (
    SELECT
        PLACE_AND_CELLS.place_uuid,
        PLACE_AND_CELLS.volume,
        PLACE_AND_CELLS.free_volume,
        PLACE_AND_CELLS.weight,
        PLACE_AND_CELLS.is_empty,
        PLACE_AND_CELLS.cell_uuid,
        PLACE_AND_CELLS.name,
        PLACE_AND_CELLS.x_coordinate,
        PLACE_AND_CELLS.y_coordinate,
        place_has_thing.thing_uuid
    FROM (
        SELECT
            PLACE_AND_CELLS_UUID.place_uuid,
            PLACE_AND_CELLS_UUID.volume,
            PLACE_AND_CELLS_UUID.free_volume,
            PLACE_AND_CELLS_UUID.weight,
            PLACE_AND_CELLS_UUID.is_empty,
            PLACE_AND_CELLS_UUID.cell_uuid,
            cell.name,
            cell.x_coordinate,
            cell.y_coordinate
        FROM (
            SELECT
              place_has_cells.place_uuid,
              place.volume,
              place.free_volume,
              place.weight,
              place.is_empty,
              place_has_cells.cell_uuid
            FROM place JOIN place_has_cells
                ON place.uuid = place_has_cells.place_uuid
        ) AS PLACE_AND_CELLS_UUID JOIN cell
            ON PLACE_AND_CELLS_UUID.cell_uuid = cell.uuid
    ) AS PLACE_AND_CELLS JOIN place_has_thing
        ON PLACE_AND_CELLS.place_uuid = place_has_thing.place_uuid
) AS PLACE_AND_CELLS_AND_THINGS JOIN thing
    ON PLACE_AND_CELLS_AND_THINGS.thing_uuid = thing.uuid;
"""

    GET_PLACES_AND_CELLS = """\
--
-- GET_PLACES_AND_CELLS
--
SELECT
    PLACE_AND_CELLS_UUID.place_uuid,
    PLACE_AND_CELLS_UUID.volume,
    PLACE_AND_CELLS_UUID.free_volume,
    PLACE_AND_CELLS_UUID.weight,
    PLACE_AND_CELLS_UUID.is_empty,
    PLACE_AND_CELLS_UUID.cell_uuid,
    cell.name,
    cell.x_coordinate,
    cell.y_coordinate
FROM (
    SELECT
      place_has_cells.place_uuid,
      place.volume,
      place.free_volume,
      place.weight,
      place.is_empty,
      place_has_cells.cell_uuid
    FROM place join place_has_cells
        ON place.uuid = place_has_cells.place_uuid
) AS PLACE_AND_CELLS_UUID JOIN cell
    ON PLACE_AND_CELLS_UUID.cell_uuid = cell.uuid;
"""

    GET_ALL_FREE_PLACES = """\
--
-- GET_ALL_FREE_PLACES
--
SELECT
    PLACE_AND_CELLS_UUID.place_uuid,
    PLACE_AND_CELLS_UUID.volume,
    PLACE_AND_CELLS_UUID.free_volume,
    PLACE_AND_CELLS_UUID.weight,
    PLACE_AND_CELLS_UUID.is_empty,
    PLACE_AND_CELLS_UUID.cell_uuid,
    cell.name,
    cell.x_coordinate,
    cell.y_coordinate
FROM (
    SELECT
      place_has_cells.place_uuid,
      place.volume,
      place.free_volume,
      place.weight,
      place.is_empty,
      place_has_cells.cell_uuid
    FROM place join place_has_cells
        ON place.uuid = place_has_cells.place_uuid and place.is_empty == 1
) AS PLACE_AND_CELLS_UUID JOIN cell
    ON PLACE_AND_CELLS_UUID.cell_uuid = cell.uuid;
"""

    CREATE_TABLES = """\
--
-- SQL CREATE TABLES
--
CREATE TABLE IF NOT EXISTS `schema` (
  `uuid` TEXT NOT NULL UNIQUE,
  PRIMARY KEY(`uuid`)
);

CREATE TABLE IF NOT EXISTS `place` (
  `uuid` TEXT NOT NULL UNIQUE,
  `volume` INTEGER NOT NULL,
  `free_volume` INTEGER NOT NULL,
  `is_empty` BOOLEAN NOT NULL DEFAULT 1,
  `weight` INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(`uuid`)
);
CREATE INDEX IF NOT EXISTS place_idx_volume ON `place`(`volume`);
CREATE INDEX IF NOT EXISTS place_idx_is_empty ON `place`(`is_empty`);
CREATE INDEX IF NOT EXISTS place_idx_weight ON `place`(`weight`);


CREATE TABLE IF NOT EXISTS `cell` (
  `uuid` TEXT NOT NULL UNIQUE,
  `x_coordinate` INTEGER NOT NULL,
  `y_coordinate` INTEGER NOT NULL,
  `name` TEXT NOT NULL, --
  `is_empty` BOOLEAN NOT NULL DEFAULT 1,
  PRIMARY KEY(`uuid`)
);

CREATE INDEX IF NOT EXISTS cell_idx_name ON `cell`(`name`);


CREATE TABLE IF NOT EXISTS `place_has_cells` (
  `place_uuid` TEXT NOT NULL,
  `cell_uuid` TEXT NOT NULL UNIQUE,
  PRIMARY KEY(`place_uuid`, `cell_uuid`),
  FOREIGN KEY(`place_uuid`) REFERENCES `place`(`uuid`),
  FOREIGN KEY(`cell_uuid`) REFERENCES `cell`(`uuid`)
);

CREATE INDEX IF NOT EXISTS `place_has_cells_idx_place_uuid`
    ON `place_has_cells`(`place_uuid`);

CREATE TABLE IF NOT EXISTS `thing` (
  `uuid` TEXT NOT NULL UNIQUE,
  `name` TEXT NOT NULL DEFAULT '',
  `mass` INTEGER NOT NULL,
  `width` INTEGER NOT NULL,
  `height` INTEGER NOT NULL,
  `depth`  INTEGER NOT NULL,
  PRIMARY KEY(`uuid`)
);

CREATE TABLE IF NOT EXISTS `place_has_thing` (
  `place_uuid` TEXT NOT NULL UNIQUE,
  `thing_uuid` TEXT NOT NULL UNIQUE,
  PRIMARY KEY(`place_uuid`, `thing_uuid`),
  FOREIGN KEY(`place_uuid`) REFERENCES `place`(`uuid`),
  FOREIGN KEY(`thing_uuid`) REFERENCES `thing`(`uuid`)
);

CREATE TABLE IF NOT EXISTS `remote_warehouse` (
  `thing_uuid` TEXT NOT NULL UNIQUE,
  PRIMARY KEY(`thing_uuid`),
  FOREIGN KEY(`thing_uuid`) REFERENCES `thing`(`uuid`)
);"""

    DROP_TABLES = """\
--
-- DROP TABLES
--
DROP INDEX IF EXISTS place_idx_volume;
DROP INDEX IF EXISTS place_idx_is_empty;
DROP INDEX IF EXISTS place_idx_weight;
DROP INDEX IF EXISTS cell_idx_name;
DROP INDEX IF EXISTS `place_has_cells_idx_place_uuid`;
DROP TABLE IF EXISTS `schema`;
DROP TABLE IF EXISTS `place_has_cells`;
DROP TABLE IF EXISTS `place_has_thing`;
DROP TABLE IF EXISTS `place`;
DROP TABLE IF EXISTS `cell`;
DROP TABLE IF EXISTS `thing`;
DROP TABLE IF EXISTS `remote_warehouse`;
"""


database_provider = DBProvider(CONFIG.get("sqlite", {}))

__all__ = ["DBProvider", "database_provider"]
