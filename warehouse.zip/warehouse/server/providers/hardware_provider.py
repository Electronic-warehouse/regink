#! /usr/bin/env python3
import requests
import json
from collections import namedtuple
from config import CONFIG


class HardwareProvider:

    def __init__(self, config):
        self._config = namedtuple(
            "HardwareHost",
            ["scheme", "host_name", "port", "path"],
            defaults=[
                config.get("scheme", "http"),
                config.get("host", "127.0.0.1"),
                config.get("port", "5000"),
                config.get("path", "/scheme")
            ]
        )()
        self._schema = None
        self.load_schema()

    @property
    def schema(self):
        return json.loads(json.dumps(self._schema))

    @property
    def url(self):
        return "".join([
            f"{self._config.scheme}://",
            f"{self._config.host_name}:{self._config.port}"
        ])

    def load_schema(self):
        if self._schema is None:
            res = requests.get(
                f"{self.url}{self._config.path}"
            )
            if res.status_code == 200:
                self._schema = res.json()
            else:
                pass
        return self._schema

    def add_thing(self, things):
        if not isinstance(things, list):
            things = [things]
        res = requests.post(self.url, json=things)
        if res.status_code != 200:
            raise Exception(res.text)

    # http://HOST:PORT/position
    def get_thing(self, place):
        # []
        if not isinstance(place, list):
            place = [place]
        data = {"destination": place}
        res = requests.get(f"{self.url}/position", json=data)
        if res.status_code == 200:
            return res.json()
        else:
            raise Exception(res.text)


hardware_provider = HardwareProvider(CONFIG.get("hardware", {}))

__all__ = ["hardware_provider", "HardwareProvider"]
