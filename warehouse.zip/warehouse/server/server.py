#! /usr/bin/env python3
import sys
from flask import Flask, render_template, redirect, request
from collections import namedtuple
from services.warehouse_service import warehouse_service
from config import CONFIG

config = namedtuple("FlaskCFG", ["name", "port", "debug", "host"], defaults=[
    CONFIG.get("flask", {}).get("name", "warehouse"),
    CONFIG.get("flask", {}).get("port", 1024),
    CONFIG.get("flask", {}).get("debug", True),
    CONFIG.get("flask", {}).get("host", "0.0.0.0")]
)()


app = Flask(config.name)


@app.route("/", methods=["GET"])
def root():
    warehouse = dict(warehouse_service.warehouse)
    things = dict(warehouse_service.remote)
    return render_template("index.html", warehouse=warehouse, things=things)


@app.route("/add", methods=["POST"])
def add_things():
    data = request.files['things'].read()
    warehouse_service.load_data(data.decode("utf-8"))
    return redirect('/')


@app.route("/", methods=["POST"])
def pull_thing():
    status_code = 302
    input_name_place_uuid = "place_uuid"
    input_name_thing_uuid = "thing_uuid"
    try:
        warehouse_service.pull_thing(
            place_uuid=request.form.get(
                input_name_place_uuid
            ),
            thing_uuid=request.form.get(
                input_name_thing_uuid
            )
        )
    except Exception as error:
        sys.stderr.write(f"{error}\n")
    return redirect("/", code=status_code)


@app.route("/api/place", methods=["GET"])
def pop_thing():
    return "Hello World\n"


def main():
    app.run(debug=config.debug, host=config.host, port=config.port)


if __name__ == "__main__":
    main()
