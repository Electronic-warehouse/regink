from collections import namedtuple
from .Identifiable import Identifiable


class Thing(Identifiable):

    def __init__(
        self,
        *,
        uuid=None,
        name,
        mass,
        width,
        height,
        depth
    ):
        super().__init__(uuid)
        self.name = name
        self.mass = mass
        self.width = width
        self.height = height
        self.depth = depth

    @property
    def volume(self):
        return self.width * self.height * self.depth

    @property
    def normal_volume(self):
        ns = self.normal_size
        return int(ns.width * ns.height * ns.depth * 1e4 + 0.5) / 1e4

    @property
    def normal_size(self):
        return namedtuple(
            "NormalSize",
            ["width", "height", "depth"],
            defaults=[
                self.width/1e3,
                self.height/1e3,
                self.depth/1e3
            ]
        )()

    def keys(self):
        return [
            "uuid",
            "name",
            "mass",
            "width",
            "height",
            "depth"
        ]

    def __getitem__(self, key):
        if key == "uuid":
            return self.uuid
        elif key == "name":
            return self.name
        elif key == "mass":
            return self.mass
        elif key == "width":
            return self.width
        elif key == "height":
            return self.height
        elif key == "depth":
            return self.depth
        else:
            return None
