from .Identifiable import Identifiable


class Cell(Identifiable):
    ASCII_SHIFT = 64

    def __init__(self, *, uuid=None, x, y):
        super().__init__(uuid)
        self.x_coordinate = x
        self.y_coordinate = y
        self.is_empty = True
        self.name = Cell.coordinatesToName(x, y)

    @staticmethod
    def coordinatesToName(x, y):
        symbol = chr(x + Cell.ASCII_SHIFT)
        return f"{symbol}{y}"

    def keys(self):
        return [
            "uuid",
            "x",
            "y",
            "is_empty",
            "name"
        ]

    def __getitem__(self, key):
        if key == "uuid":
            return self.uuid
        elif key == "x":
            return self.x_coordinate
        elif key == "y":
            return self.y_coordinate
        elif key == "is_empty":
            return self.is_empty
        elif key == "name":
            return self.name
        else:
            return None
