from .Identifiable import Identifiable
from .Cell import Cell
from .Thing import Thing


class Place(Identifiable):
    def __init__(self, *, uuid=None, volume=0, cells=[], weight=0):
        super().__init__(uuid)
        self.weight = weight
        self.free_volume = volume
        self.volume = volume
        self.cells = {}
        self.things = {}
        self.add_cells(cells)

    def find(self, thing_uuid):
        return self.things.get(thing_uuid)

    def push(self, thing):
        if not bool(list(self.things.keys())):
            self.things[thing.uuid] = thing

    def pop(self):
        if not self.is_empty:
            return self.things.pop(list(self.things.keys())[0])

    def add_cells(self, cells, autoinc=True):
        if not isinstance(cells, list):
            cells = [cells]
        for cell in cells:
            if isinstance(cell, Cell):
                if self.cells.get(cell.uuid) is None:
                    self.cells[cell.uuid] = cell
                    if autoinc:
                        self.free_volume += 1
                        self.volume += 1

    @property
    def name(self):
        names = [cell.name for cell in self.cells.values()]
        names.sort()
        return " ".join(names)

    def add_thing(self, thing: Thing):
        if not self.is_empty:
            raise Exception(f"place {self.name} is not empty")
        elif self.volume < thing.volume:
            raise Exception("volume is not enough")
        elif self.free_volume < thing.valume:
            raise Exception(f"thin {thing.uuid} is very large")
        else:
            self.is_empty = False
            self.things[thing.uuid] = thing
            self.free_volume -= thing.volume

    @property
    def is_empty(self):
        return not bool(list(self.things.keys()))

    @property
    def is_full(self):
        return bool(self.things.keys())

    def keys(self):
        return [
            "uuid",
            "name",
            "volume",
            "free_volume",
            "is_empty",
            "cells",
            "things"
        ]

    def __getitem__(self, key):
        if key == "uuid":
            return self.uuid
        elif key == "name":
            return self.name
        elif key == "volume":
            return self.volume
        elif key == "free_volume":
            return self.free_volume
        elif key == "is_empty":
            return self.is_empty
        elif key == "cells":
            return dict(zip(
                self.cells.keys(),
                [dict(cell) for cell in self.cells.values()]
            ))
        elif key == "things":
            return dict(zip(
                self.things.keys(),
                [dict(thing) for thing in self.things.values()]
            ))
        else:
            return None
