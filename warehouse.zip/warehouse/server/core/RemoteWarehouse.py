from Thing import Thing


class RemoteWarehouse(list):

    def __init__(self, things):
        super().__init__()

        for thing in things:
            self.append(thing)

    def append(self, thing: Thing):
        if isinstance(thing, Thing):
            super.append(thing)
