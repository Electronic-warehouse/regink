from collections import namedtuple
from io import StringIO
from .Identifiable import Identifiable
from .Thing import Thing
import csv


class Invoice(Identifiable, list):

    def __init__(self, *, data, uuid=None):
        super().__init__(uuid)
        self.__read(data)

    def __read(self, data):
        fp = StringIO(data)
        reader = csv.reader(fp)
        tableKeys = Invoice.makeTableKeys()
        for index, row in enumerate(reader):
            if index != 0:
                try:
                    size = [int(i) for i in row[tableKeys.size].split("*")]
                    thing = Thing(
                        name=row[tableKeys.name],
                        width=size[0],
                        height=size[1],
                        depth=size[2],
                        mass=row[tableKeys.mass]
                    )
                    self.append(thing)
                except Exception as error:
                    print(error)

    @staticmethod
    def makeTableKeys():
        return namedtuple(
            "Keys",
            ["number", "name", "size", "mass"],
            defaults=[0, 1, 2, 3]
        )()
