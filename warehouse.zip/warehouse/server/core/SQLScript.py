from collections import namedtuple


class SQLScript:
    def __init__(self, *, script, attrs_name):
        self.attributes = SQLScript.make_attributes(attrs_name)

    @property
    def attributes(self):
        return

    @staticmethod
    def make_attributes(names):
        return namedtuple(
            "Attributes",
            names,
            defaults=list(range(len(names)))
        )()
