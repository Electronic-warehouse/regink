from .Identifiable import Identifiable
from .Place import Place


class Warehouse(Identifiable):

    def __init__(self, *, uuid=None, places={}):
        super().__init__(uuid)
        self.places = places
        self.free_places = {}
        self.busy_places = {}

    def add_place(self, place):
        if isinstance(place, Place):
            self.places[place.uuid] = place
            if place.is_empty:
                self.free_places[place.uuid] = place
            else:
                self.busy_places[place.uuid] = place

    def find(self, uuid):
        return self.places.get(uuid)

    def add_thing(self, thing):
        place = None
        for _place in self.free_places.values():
            if _place.volume >= thing.normal_volume:
                _place.push(thing)
                place = _place
                break
        if place is None:
            raise Exception("place not found")
        else:
            self.busy_places[place.uuid] = self.free_places.pop(place.uuid)
        return place

    def take_thing(self):
        pass

    def keys(self):
        return ["uuid", "places"]

    def pull_thing(self, place):
        self.free_places[place.uuid] = self.busy_places.pop(place.uuid)
        place.pop()

    def __getitem__(self, key):
        if key == "uuid":
            return self.uuid
        elif key == "places":
            return dict(zip(
                self.places.keys(),
                [dict(place) for place in self.places.values()]
            ))
        else:
            return None
