# 

Запуск приложения

```bash
make run
```
